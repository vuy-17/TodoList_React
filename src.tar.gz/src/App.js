import React, { Component } from 'react';
class App extends Component {
    render() {
        var myStyle={
            fontSize:80
        }
        return ( <div >
            
            <h1 style={myStyle}> JavaTpoint < /h1>   
            <h2 > Training Institutes < /h2>  
             <p name="hi"> This website contains the best CS tutorials. < /p>
             <First/>   
             </div >
        );
    }
}

class First extends Component{
    render(){
        var myStyle={
            fontSize:80,
            
        }
        return (
            <div>
            <p style={myStyle}>Pranjali</p>
            </div>
        );
    }
}

export default App;